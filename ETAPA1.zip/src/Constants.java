public class Constants {
    public static final int BOARD_LENGTH = 120;
    public static final int E = 0;
    public static final int wK = 1;
    public static final int wQ = 2;
    public static final int wR = 3;
    public static final int wB = 4;
    public static final int wN = 5;
    public static final int wP = 6;
    public static final int bK = 7;
    public static final int bQ = 8;
    public static final int bR = 9;
    public static final int bB = 10;
    public static final int bN = 11;
    public static final int bP = 12;

}
